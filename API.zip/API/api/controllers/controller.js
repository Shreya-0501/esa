var mongoose = require('mongoose');
// const { MongoClient } = require('mongodb');

User = mongoose.model('User');
Product = mongoose.model('Product');
Cart = mongoose.model('Cart');

// const uri = "mongodb+srv://Shreya:shreya@cluster0.cmsbhy5.mongodb.net/esa_assignment?retryWrites=true&w=majority"

// const client = new MongoClient(uri);

// client.connect();
// GET ../users
exports.get_users = function(req, res){
    User.find({}, function(err, user){
        if(err){
            res.send(err);
        }
        res.json(user);
        console.log(user);
    });
};

// exports.get_users = async function (req,res) {
//     const result = await client.db("esa_assignment").collection("User").find({function(err,results){
//         assert.equal(null, err);
        
//         //invoke callback with your mongoose returned result
//         callback(results);
//     }})
//     // // result.lean();
//     // if (result) {
//     //     console.log(`Found a listing in the collection with the name `);
//     //     console.log(result);
//     // } else {
//     //     console.log(`No listings found with the name`);
//     // }
// }

// GET ../users/user_id
exports.get_user = function(req,res){
    User.find({user_id:req.params.user_id},function(err,user){
        if(err){
            res.send(err);
        }
        res.json(user);
    });
};

// GET ../products
exports.get_products = function(req, res){
    Product.find({}, function(err, product){
        if(err){
            res.send(err);
        }
        res.json(product);
        console.log(product);
    });
};

// GET ../users/user_id/cart
exports.get_cart = function(req,res){
    Cart.find({user_id:req.params.user_id},function(err,cart){
        if(err){
            res.send(err);
        }
        res.json(cart);
    });
};

exports.put_to_cart = function(req,res){
    Cart.find({user_id: req.params.user_id})
    .exec((err, cart) => {
        console.log(cart)
        if(err){
            return res.status(400).json({err});
        }
        if(cart){
            // Cart.findOneAndUpdate({user_id: req.params.user_id}, {
            //     $push : {
            //         cartItems: req.body.cartItems
            //     }
            //     // { $push: { reviews: built_review }}, function(err, result){
            // },function(err, cart){
            //     console.log("Found");
            //     return res.status(201).json({cart});
            // });
            var array = {
                "productId": req.body.productId,
                "quantity": req.body.quantity,
                "amount": req.body.amount
            }
            Cart.findOneAndUpdate(
                {user_id: req.params.user_id},
                { $push: { cartItems: array}}, function(err, result){
        
                    if(err) console.log(err)
                    res.send(result);
            })
        }

        else{
            var cart = new Cart({
                user_id: req.params.user_id,
                cartItems: [req.body.cartItems]
            });
            cart.save((err,cart) => {
                if(err){
                    return res.status(400).json({err});
                }
                if(cart){
                    return res.status(201).json({cart});
                }
            })
        }
    })
};


  