var mongoose = require('mongoose');
var Schema = mongoose.Schema;
const uri = "mongodb+srv://Shreya:shreya@cluster0.cmsbhy5.mongodb.net/esa_2?retryWrites=true&w=majority"
const db = mongoose.createConnection(uri,{ useNewUrlParser: true , useUnifiedTopology: true})

var userSchema = new Schema({
    user_id: String,
    username: String 
})

var productSchema = new Schema({
    productId: String,
    category: String,
    productName: String,
    productModel: String,
    price: Number,
    availableQuantity: Number
})

var cartSchema = new Schema({
    user_id: String,
    productId: String,
    productName: String,
    amount: Number,
    quantity: Number
})

var cartItemSchema = new Schema({
    productId: String,
    productName: String,
    quantity: Number,
    amount: Number
});

const Test = mongoose.model('CartItem', cartItemSchema)
const test = new Test({
    "productId": "12445dsd234",
    "productName": "Samsung",
    "quantity": 2,
    "amount": 1400
})

const Test3 = mongoose.model('Product', productSchema)
const test3 = new Test3({
    "productId": "12445dsd234",
    "category": "Modile",
    "productName": "Samsung",
    "productModel": "GalaxyNote",
    "price":700,
    "availableQuantity":10
})

const Test4 = mongoose.model('User', userSchema)
const test4 = new Test4({
    "productId": "12445dsd234",
    "productName": "Samsung",
    "quantity": 2,
    "amount": 1400
})

const Test2 = mongoose.model('Cart', cartSchema)
const test2 = new Test2({
    "user_id": "qa-test-user",
    "cart": [
        {
            "productId": "12445dsd234",
            "productName": "Samsung",
            "quantity": 2,
            "amount": 1400
        },
        {
            "productId": "123245ds4234",
            "productName": "Sony",
            "quantity": 1,
            "amount": 1200
        }
    ]
})

// db.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test.create(test, function (err, doc) {
//       if (err) { return console.error(err) }
//     //   console.log(doc)
//       return db.close()
//     }) 
//   });

// db.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test2.create(test2, function (err, doc) {
//       if (err) { return console.error(err) }
//     //   console.log(doc)
//       return db.close()
//     }) 
//   });

// db.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test3.create(test3, function (err, doc) {
//       if (err) { return console.error(err) }
//     //   console.log(doc)
//       return db.close()
//     }) 
//   });

// db.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test4.create(test4, function (err, doc) {
//       if (err) { return console.error(err) }
//     //   console.log(doc)
//       return db.close()
//     }) 
//   })

module.exports = mongoose.model('User', userSchema)
module.exports = mongoose.model('Product', productSchema)
module.exports = mongoose.model('Cart', cartSchema)
module.exports = mongoose.model('CartItem', cartItemSchema)