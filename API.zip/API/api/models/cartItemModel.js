var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var cartItemSchema = new Schema({
    productId: String,
    productName: String,
    quantity: Number,
    amount: Number
});

const Test = mongoose.model('CartItem', cartItemSchema)
const test = new Test({
    "productId": "12445dsd234",
    "productName": "Samsung",
    "quantity": 2,
    "amount": 1400
})

// module.exports = mongoose.model('CartItem', cartItemSchema);
// test.save((err) => {
//     if (err) return handleError(err);
//     // saved!
//     console.log("carItem done")
//   });

// mongoose.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test.create(test, function (err, doc) {
//       if (err) { return console.error(err) }
//       console.log(doc)
//       return mongoose.close()
//     }) 
//   })