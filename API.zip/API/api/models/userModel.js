var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    user_id: {
        type: String,
        required: true,
        unique: true
    },
    username: {
        type: String,
        required: true
    }
});

const Test4 = mongoose.model('User', userSchema)
const test4 = new Test4({
    "productId": "12445dsd234",
    "productName": "Samsung",
    "quantity": 2,
    "amount": 1400
})

// test4.save((err) => {
//     if (err) return handleError(err);
//     // saved!
//     console.log("user done")
//   });

// mongoose.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test4.create(test4, function (err, doc) {
//       if (err) { return console.error(err) }
//       console.log(doc)
//       return mongoose.close()
//     }) 
//   })

// module.exports = mongoose.model('User', userSchema);