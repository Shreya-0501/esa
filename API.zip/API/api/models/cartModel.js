var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var cartSchema = new Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    cartItems: [
        {
            productId: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Product',
                required: true
            },
            quantity: {
                type: Number,
                default: 1,
            },
            amount: {
                type: Number,
                required: true
            }
        }
    ]
});

const Test2 = mongoose.model('Cart', cartSchema)
const test2 = new Test2({
    "user_id": "qa-test-user",
    "cart": [
        {
            "productId": "12445dsd234",
            "productName": "Samsung",
            "quantity": 2,
            "amount": 1400
        },
        {
            "productId": "123245ds4234",
            "productName": "Sony",
            "quantity": 1,
            "amount": 1200
        }
    ]
})

// test2.save((err) => {
//     if (err) return handleError(err);
//     // saved!
//     console.log("cart done")
//   });

// mongoose.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test2.create(test2, function (err, doc) {
//       if (err) { return console.error(err) }
//       console.log(doc)
//       return mongoose.close()
//     }) 
//   })

// module.exports = mongoose.model('Cart', cartSchema);