var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var productSchema = new Schema({
    productId: {
        type: String,
        required: true,
        unique: true
    },
    category: {
        type: String,
        required: true
    },
    productName: {
        type: String,
        required: true
    },
    productModel: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    availableQuantity: {
        type: Number,
        required: true
    }
});

const Test3 = mongoose.model('Product', productSchema)
const test3 = new Test3({
    "productId": "12445dsd234",
    "category": "Modile",
    "productName": "Samsung",
    "productModel": "GalaxyNote",
    "price":700,
    "availableQuantity":10

})

// test3.save((err) => {
//     if (err) return handleError(err);
//     // saved!
//     console.log("product done")
//   });

// mongoose.once('connected', function (err) {
//     if (err) { return console.error(err) }
//     Test3.create(test3, function (err, doc) {
//       if (err) { return console.error(err) }
//       console.log(doc)
//       return mongoose.close()
//     }) 
//   })

// module.exports = mongoose.model('Product', productSchema);